//
//  enumSegue.swift
//  Midterm_2022
//
//  Created by Niravkumar Savsani on 2022-03-10.
//

import Foundation

enum Segue {
    static let toStudentListView : String = "toStudentListView"
    static let toStudentInfoView : String = "toStudentInfoView"
    static let toStudentInfoViewEditing : String = "toStudentInfoViewEditing"
    
}
